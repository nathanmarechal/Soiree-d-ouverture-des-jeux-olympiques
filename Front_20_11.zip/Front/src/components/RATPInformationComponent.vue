<template>
  <div class="ratp-image-container">
    <img src="../assets/ratp.jpg" alt="Background" class="ratp-img-fluid w-100 h-100">
    <div class="ratp-overlay-text">
      <div class="ratp-text-content">
        <p>{{ ratpDescription }}</p>
        <button class="ratp-overlay-button">Cliquez ici</button>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      ratpDescription: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas suscipit sem eget dui blandit, eget ullamcorper odio interdum. Sed vel nunc ac sapien facilisis ultricies. Sed luctus nunc non dolor semper, non mattis felis bibendum. Nunc vitae ante eget tortor aliquet consectetur. Aliquam erat volutpat. Duis vel hendrerit lorem. Nullam aliquet felis eu nulla mattis, eget vehicula tortor ultricies. Aenean varius purus nec mauris tincidunt, non pharetra felis fringilla. Maecenas mattis consectetur mi, nec sollicitudin ipsum euismod a. Nullam in luctus nisl. Integer auctor, odio eget iaculis facilisis, lectus justo malesuada nisl, sed posuere metus neque nec nisi. Sed venenatis, libero in venenatis malesuada, nulla ligula aliquet nulla, vel consectetur tortor dolor nec justo. Vestibulum consequat elit ac tortor interdum, a consectetur sapien varius. Vivamus interdum, justo in tincidunt faucibus, urna ex viverra arcu, sit amet mattis libero turpis vel sapien"
    }
  }
}
</script>

<style scoped>
.ratp-image-container {
  position: relative;
  height: 100vh;
  overflow: hidden;
}

.ratp-image-container img {
  object-fit: cover;
}

.ratp-overlay-text {
  position: absolute;
  top: 50%;
  left: 0;
  transform: translateY(-50%);
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: flex-end;
  width: 50%;
  gap: 20px;
}


.ratp-overlay-text p {
  color: white;
  font-size: 24px;
  text-align: justify;
  margin: 0;
}


.ratp-text-content {
  max-width: 90%;
  background-color: rgba(0, 0, 0, 0.5);
  padding: 20px;
  border-radius: 5px;
  display: flex;
  flex-direction: column;
  gap: 10px;
}



.ratp-overlay-button {
  align-self: flex-end;
  padding: 10px 20px;
  background-color: #D8C17B;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  transition: background-color 0.3s;
}


.ratp-overlay-button:hover {
  background-color: #a09860;
}

</style>
